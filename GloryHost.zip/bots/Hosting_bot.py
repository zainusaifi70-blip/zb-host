import telebot
import os
import subprocess
import threading
import time
import uuid
import zipfile
import shutil

TOKEN = "8508126044:AAFt_8s5-cQFxS9OTvdvaHhgTMToemvM6sg"
bot = telebot.TeleBot(TOKEN)

USERS = set()
FILES = {}
SELECTED = {}
RUNNING = {}
PROCESSES = {}

UPLOAD_LIMIT = 3

from telebot.types import ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton

# ===== MENU =====
def main_menu():
    m = ReplyKeyboardMarkup(resize_keyboard=True)
    m.add("📤 Upload File", "📁 My Files")
    m.add("⚡ Bot Speed", "📊 Statistics")
    return m

# ===== START =====
@bot.message_handler(commands=['start'])
def start(msg):
    uid = msg.from_user.id
    USERS.add(uid)

    count = len(FILES.get(uid, []))

    bot.send_message(msg.chat.id,
        f"⚡ Welcome, {msg.from_user.first_name}!\n\n"
        f"🆔 ID: {uid}\n"
        f"👤 Username: @{msg.from_user.username}\n"
        f"📦 Status: Free User\n"
        f"📂 Files Uploaded: {count} / {UPLOAD_LIMIT}\n\n"
        f"🤖 Host & run Python (.py) or JS (.js)\n"
        f"📁 Upload single file or .zip\n\n"
        f"👇 Use buttons below",
        reply_markup=main_menu()
    )

# ===== UPLOAD =====
@bot.message_handler(func=lambda m: m.text == "📤 Upload File")
def upload(msg):
    bot.send_message(msg.chat.id, "📤 Send .py / .js / .zip")

@bot.message_handler(content_types=['document'])
def handle_file(msg):
    uid = msg.from_user.id

    if uid not in FILES:
        FILES[uid] = []

    if len(FILES[uid]) >= UPLOAD_LIMIT:
        bot.send_message(msg.chat.id, "❌ Limit reached")
        return

    file_info = bot.get_file(msg.document.file_id)
    data = bot.download_file(file_info.file_path)

    name = f"{uuid.uuid4()}_{msg.document.file_name}"
    path = f"files/{name}"

    os.makedirs("files", exist_ok=True)

    with open(path, "wb") as f:
        f.write(data)

    if name.endswith(".zip"):
        extract_path = path.replace(".zip", "")
        os.makedirs(extract_path, exist_ok=True)

        with zipfile.ZipFile(path, 'r') as zip_ref:
            zip_ref.extractall(extract_path)

        FILES[uid].append(extract_path)
        bot.send_message(msg.chat.id, "📦 ZIP Extracted")
    else:
        FILES[uid].append(path)
        bot.send_message(msg.chat.id, "✅ Uploaded")

# ===== FILE PANEL =====
@bot.message_handler(func=lambda m: m.text == "📁 My Files")
def files_panel(msg):
    uid = msg.from_user.id

    if uid not in FILES or not FILES[uid]:
        bot.send_message(msg.chat.id, "📂 No files")
        return

    kb = InlineKeyboardMarkup()
    for i, f in enumerate(FILES[uid]):
        kb.add(InlineKeyboardButton(os.path.basename(f), callback_data=f"select_{i}"))

    bot.send_message(msg.chat.id, "📁 Select file:", reply_markup=kb)

# ===== SELECT =====
@bot.callback_query_handler(func=lambda c: c.data.startswith("select_"))
def select_file(call):
    uid = call.from_user.id
    index = int(call.data.split("_")[1])

    SELECTED[uid] = FILES[uid][index]

    kb = InlineKeyboardMarkup()
    kb.add(
        InlineKeyboardButton("▶️ Run", callback_data="run"),
        InlineKeyboardButton("📜 Logs", callback_data="logs")
    )
    kb.add(
        InlineKeyboardButton("⛔ Stop", callback_data="stop"),
        InlineKeyboardButton("🔁 Restart", callback_data="restart")
    )
    kb.add(
        InlineKeyboardButton("🗑️ Delete", callback_data="delete")
    )

    bot.edit_message_text(
        f"📄 {os.path.basename(SELECTED[uid])}",
        call.message.chat.id,
        call.message.message_id,
        reply_markup=kb
    )

# ===== INSTALL =====
def install_requirements(chat_id, path):
    for root, dirs, files in os.walk(path):
        if "requirements.txt" in files:
            req = os.path.join(root, "requirements.txt")
            bot.send_message(chat_id, "📦 Installing modules, please wait...")
            subprocess.run(["pip", "install", "-r", req])
            bot.send_message(chat_id, "✅ Installed")
            break

# ===== RUN =====
def run_script(uid, path, chat_id):
    try:
        RUNNING[uid] = True

        if os.path.isdir(path):
            install_requirements(chat_id, path)

            for root, dirs, files in os.walk(path):
                if "main.py" in files:
                    path = os.path.join(root, "main.py")
                    break
                if "index.js" in files:
                    path = os.path.join(root, "index.js")
                    break

        if path.endswith(".py"):
            cmd = ["python3", path]
        elif path.endswith(".js"):
            cmd = ["node", path]
        else:
            bot.send_message(chat_id, "❌ Unsupported")
            return

        log_file = open(f"log_{uid}.txt", "w")

        p = subprocess.Popen(cmd, stdout=log_file, stderr=log_file)
        PROCESSES[uid] = p

        bot.send_message(chat_id, "🚀 Running (background)")

    except Exception as e:
        bot.send_message(chat_id, f"❌ {e}")

# ===== BUTTONS =====
@bot.callback_query_handler(func=lambda c: c.data == "run")
def run_btn(call):
    uid = call.from_user.id
    threading.Thread(target=run_script, args=(uid, SELECTED[uid], call.message.chat.id)).start()

@bot.callback_query_handler(func=lambda c: c.data == "logs")
def logs_btn(call):
    uid = call.from_user.id
    try:
        with open(f"log_{uid}.txt", "r") as f:
            data = f.read()[-4000:]
            bot.send_message(call.message.chat.id, f"📜 Logs:\n{data}")
    except:
        bot.send_message(call.message.chat.id, "❌ No logs")

@bot.callback_query_handler(func=lambda c: c.data == "stop")
def stop_btn(call):
    uid = call.from_user.id

    if uid in PROCESSES:
        PROCESSES[uid].terminate()
        bot.send_message(call.message.chat.id, "⛔ Stopped")
    else:
        bot.send_message(call.message.chat.id, "❌ Not running")

@bot.callback_query_handler(func=lambda c: c.data == "restart")
def restart_btn(call):
    uid = call.from_user.id

    if uid in PROCESSES:
        PROCESSES[uid].terminate()

    threading.Thread(target=run_script, args=(uid, SELECTED[uid], call.message.chat.id)).start()
    bot.send_message(call.message.chat.id, "🔁 Restarted")

@bot.callback_query_handler(func=lambda c: c.data == "delete")
def delete_btn(call):
    uid = call.from_user.id
    path = SELECTED[uid]

    try:
        if os.path.isfile(path):
            os.remove(path)
        else:
            shutil.rmtree(path)

        FILES[uid].remove(path)
        SELECTED.pop(uid)

        bot.send_message(call.message.chat.id, "🗑️ Deleted")
    except:
        bot.send_message(call.message.chat.id, "❌ Error")

# ===== SPEED =====
@bot.message_handler(func=lambda m: m.text == "⚡ Bot Speed")
def speed(msg):
    s = time.time()
    bot.send_message(msg.chat.id, "⚡ Checking...")
    e = time.time()
    bot.send_message(msg.chat.id, f"⚡ {round((e-s)*1000,2)} ms")

# ===== STATS =====
@bot.message_handler(func=lambda m: m.text == "📊 Statistics")
def stats(msg):
    bot.send_message(msg.chat.id,
        f"📊 Stats\n\n"
        f"👥 Users: {len(USERS)}\n"
        f"📂 Files: {sum(len(v) for v in FILES.values())}\n"
        f"🤖 Running: {len(PROCESSES)}"
    )

print("🔥 PRO BOT RUNNING...")
bot.infinity_polling()